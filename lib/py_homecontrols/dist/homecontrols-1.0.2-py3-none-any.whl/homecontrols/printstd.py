def data(data):
  print("DATA: {}".format(data))
  return

def cmdData(data):
  print("CMDATA: {}".format(data))
  return

def error(data):
  print("# ERROR: {}".format(data))
  return

def warn(data):
  print("# WARN: {}".format(data))
  return

def event(data):
  print("EVENT: {}".format(data))
  return