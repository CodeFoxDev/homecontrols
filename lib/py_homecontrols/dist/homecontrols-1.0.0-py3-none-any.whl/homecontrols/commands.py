import sys

regCommands = {}

def when(command, function):
  regCommands[command] = function

def execute():
  n = len(sys.argv)
  cmdString = ""
  for i in range(1, n):
    cmdString += sys.argv[i]
    cmdString += " "
  
  # Execute right command
  
  return cmdString