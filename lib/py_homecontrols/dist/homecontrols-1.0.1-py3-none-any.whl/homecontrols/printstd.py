def data():
  return

def cmdData():
  return

def error():
  return

def warn():
  return

def event():
  return